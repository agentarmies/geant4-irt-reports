// Exact source-fragment fixture; real Geant4 lists, no transport or chemistry.
// Sampling records the call and optionally appends one associated sublist.
#include "G4TrackList.hh"
#include "G4Molecule.hh"
#include "G4H2O.hh"
#include "G4Scheduler.hh"
#include "G4SystemOfUnits.hh"
#include "IRTCacheGuard.hh"
#include "IRTOrderedTracks.hh"
#include <array>
#include <fstream>
#include <iomanip>
#include <map>
#include <memory>
#include <string>
#include <vector>

struct OwnedLists {
  G4TrackManyList list;
  std::vector<std::unique_ptr<G4TrackList>> parts;
  std::vector<G4Track*> tracks; // Observers only; each sublist owns its tracks.
  void Append(const std::vector<int>& ids) {
    auto part=std::make_unique<G4TrackList>();
    for(int id:ids) {
      auto* track=new G4Track;
      auto* molecule=new G4Molecule(G4H2O::Definition());
      molecule->SetTrack(track);track->SetUserInformation(molecule);
      track->SetTrackID(id);track->SetGlobalTime(1*ps);
      track->SetPosition(G4ThreeVector(id*13.,id*id*.75,-id*3.)*nm);
      part->push_back(track);tracks.push_back(track);
    }
    list.Add(part.get());parts.push_back(std::move(part));
  }
  ~OwnedLists() {
    list.ClearLists(); // Deletes tracks, but not the associated sublists.
    parts.clear();     // Deletes sublists and unregisters them before list dies.
  }
};
struct Holder {
  G4TrackManyList* list;
  G4TrackManyList* GetMainList(){return list;}
};
struct ReactionSet {bool Empty()const{return true;}};
struct FixtureIRT {
  OwnedLists& owned;
  Holder holder;Holder* fTrackHolder=&holder;
  ReactionSet reactions;ReactionSet* fReactionSet=&reactions;
  G4double fXMin=1e9*nm,fYMin=1e9*nm,fZMin=1e9*nm,fXMax=0,fYMax=0,fZMax=0;
  G4double fRCutOff=100*nm;
  G4int fNx=0,fNy=0,fNz=0;
  std::map<G4int,std::map<G4int,std::map<G4int,std::vector<G4Track*>>>> spaceBinned;
  std::vector<int> calls;
  std::vector<std::array<int,4>> orderedInsertions;
  int appendAt=0;std::vector<int> appendIds;bool appended=false;
  explicit FixtureIRT(OwnedLists& input):owned(input),holder{&input.list}{}
  void SpaceBinning();void IRTSampling();
  G4int FindBin(G4int,G4double,G4double,G4double);
  void Sampling(G4Track* track) {
    const auto& p=track->GetPosition();
    const auto i=FindBin(fNx,fXMin,fXMax,p.x()),j=FindBin(fNy,fYMin,fYMax,p.y()),k=FindBin(fNz,fZMin,fZMax,p.z());
    const auto& inserted=spaceBinned[i][j][k];
    if(inserted.empty() || inserted.back()!=track)
      throw std::runtime_error("sampling did not follow this track's actual bin insertion");
    calls.push_back(track->GetTrackID());
    orderedInsertions.push_back({i,j,k,track->GetTrackID()});
    if(appendAt!=0 && !appended && track->GetTrackID()==appendAt) {
      owned.Append(appendIds);appended=true;
    }
  }
  void EndWhenReactionSetEmpty(){
if(fReactionSet->Empty())
  {
    forEachIRTTrack(*fTrackHolder->GetMainList(), [](G4Track* pTrack) {
      pTrack->SetGlobalTime(G4Scheduler::Instance()->GetEndTime());
    });
  }
  }
};
void FixtureIRT::SpaceBinning(){
  forEachIRTTrack(*fTrackHolder->GetMainList(), [&](G4Track* track) {

    G4ThreeVector position = track->GetPosition();

    if ( fXMin > position.x() ) fXMin = position.x(); 
    if ( fYMin > position.y() ) fYMin = position.y();
    if ( fZMin > position.z() ) fZMin = position.z();

    if ( fXMax < position.x() ) fXMax = position.x();
    if ( fYMax < position.y() ) fYMax = position.y();
    if ( fZMax < position.z() ) fZMax = position.z();

  });

  fNx = G4int((fXMax-fXMin)/fRCutOff) == 0 ? 1 : G4int((fXMax-fXMin)/fRCutOff);
  fNy = G4int((fYMax-fYMin)/fRCutOff) == 0 ? 1 : G4int((fYMax-fYMin)/fRCutOff);
  fNz = G4int((fZMax-fZMin)/fRCutOff) == 0 ? 1 : G4int((fZMax-fZMin)/fRCutOff);

}
void FixtureIRT::IRTSampling(){

  forEachIRTTrack(*fTrackHolder->GetMainList(), [&](G4Track* track) {
    G4int I = FindBin(fNx, fXMin, fXMax, track->GetPosition().x());
    G4int J = FindBin(fNy, fYMin, fYMax, track->GetPosition().y());
    G4int K = FindBin(fNz, fZMin, fZMax, track->GetPosition().z());

    spaceBinned[I][J][K].push_back(track);
    RadIRTCacheGuard::inserted(I,J,K,track);

    Sampling(track);
  });
}
G4int FixtureIRT::FindBin(G4int n, G4double xmin, G4double xmax, G4double value) {

  G4int bin = -1;
  if ( value <= xmin )
    bin = 0; //1;
  else if ( value >= xmax)  //!(xmax < value) ) //value >= xmax )
    bin = n-1; //n;
  else
    bin = G4int( n * ( value - xmin )/( xmax - xmin ) ); //bin = 1 + G4int( n * ( value - xmin )/( xmax - xmin ) );

  if ( bin < 0 ) bin = 0;
  if ( bin >= n ) bin = n-1;

  return bin;
}

int main(int argc,char** argv) {
  if(argc!=2)return 64;
  RadIRTCacheGuard::Tag::key();
  G4Scheduler::Instance()->SetEndTime(20*us);
  using Layout=std::vector<std::vector<int>>;
  const std::vector<Layout> layouts={
    {},{{}},{{},{},{}},{{17}},{{-9}},{{-31,4,-2,55}},
    {{},{81,-17},{},{2},{},{-6,9},{}},{{4},{-4},{10}},{{42,-42},{},{7}},
    {{11,22},{33}},{{11,22},{33}},{{11,22},{33}}
  };
  std::ofstream out(argv[1]);out<<std::setprecision(17)<<"{\"fixtures\":[";
  for(std::size_t i=0;i<layouts.size();++i) {
    OwnedLists owned;
    for(const auto& group:layouts[i])owned.Append(group);
    RadIRTCacheGuard::reset();
    FixtureIRT fixture(owned);
    if(i==9 || i==11)fixture.appendAt=22;
    if(i==10)fixture.appendAt=33;
    if(i==11)fixture.appendIds={18,28};
    fixture.SpaceBinning();fixture.IRTSampling();fixture.EndWhenReactionSetEmpty();
    if(i)out<<',';
    out<<"{\"index\":"<<i<<",\"bounds_nm\":["<<fixture.fXMin/nm<<','<<fixture.fXMax/nm<<','
       <<fixture.fYMin/nm<<','<<fixture.fYMax/nm<<','<<fixture.fZMin/nm<<','<<fixture.fZMax/nm
       <<"],\"bin_counts\":["<<fixture.fNx<<','<<fixture.fNy<<','<<fixture.fNz<<"],\"ordered_insertions\":[";
    for(std::size_t j=0;j<fixture.orderedInsertions.size();++j) {
      if(j)out<<',';const auto& a=fixture.orderedInsertions[j];
      out<<'['<<a[0]<<','<<a[1]<<','<<a[2]<<','<<a[3]<<']';
    }
    out<<"],\"bins\":[";bool firstBin=true;
    for(const auto& x:fixture.spaceBinned)for(const auto& y:x.second)for(const auto& z:y.second) {
      if(!firstBin)out<<',';firstBin=false;
      out<<'['<<x.first<<','<<y.first<<','<<z.first<<",[";
      for(std::size_t j=0;j<z.second.size();++j){if(j)out<<',';out<<z.second[j]->GetTrackID();}
      out<<"]]";
    }
    out<<"],\"sampling_call_ids\":[";
    for(std::size_t j=0;j<fixture.calls.size();++j){if(j)out<<',';out<<fixture.calls[j];}
    out<<"],\"append_trigger_id\":"<<fixture.appendAt<<",\"sublist_appended\":"
       <<(fixture.appended ? "true" : "false")<<",\"associated_sublists_after\":"<<owned.parts.size()
       <<",\"appended_ids\":[";
    for(std::size_t j=0;j<fixture.appendIds.size();++j){if(j)out<<',';out<<fixture.appendIds[j];}
    out<<"],\"final_tracks\":[";
    for(std::size_t j=0;j<owned.tracks.size();++j) {
      if(j)out<<',';out<<"{\"id\":"<<owned.tracks[j]->GetTrackID()<<",\"time_ns\":"
        <<owned.tracks[j]->GetGlobalTime()/ns<<",\"status\":"<<int(owned.tracks[j]->GetTrackStatus())<<'}';
    }
    out<<"]}";
  }
  out<<"]}\n";out.flush();return out.good()?0:1;
}
