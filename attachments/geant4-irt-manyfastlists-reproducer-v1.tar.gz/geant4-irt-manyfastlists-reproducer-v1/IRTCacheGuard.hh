#pragma once
// Traditional IRT cache lifetime guard. No cache observer, counters or logging.
// A cached partner is usable only while its insertion ID and generation are live.
#include "G4Track.hh"
#include "G4PhysicsModelCatalog.hh"
#include "G4VAuxiliaryTrackInformation.hh"
#include <cstdint>
#include <exception>
#include <map>
#include <stdexcept>
#include <tuple>
#include <unordered_map>
#include <vector>

namespace RadIRTCacheGuard {
struct Identity {int id; std::uint64_t generation;};
struct Registry {
  std::uint64_t next=0;
  std::unordered_map<const G4Track*,Identity> live;
};
inline Registry& registry() {
  // Geant4 can destroy track metadata during thread teardown. The registry
  // outlives those tracks; every live entry is erased by its track-owned tag.
  static thread_local auto* value=new Registry;
  return *value;
}
struct Tag final : G4VAuxiliaryTrackInformation {
  const G4Track* track;
  std::uint64_t generation;
  explicit Tag(const G4Track& t):track(&t),generation(++registry().next) {
    if(!generation || registry().live.count(track))
      throw std::runtime_error("duplicate live molecular generation");
    registry().live.emplace(track,Identity{t.GetTrackID(),generation});
  }
  ~Tag() override {
    auto& live=registry().live;
    const auto it=live.find(track);
    if(it==live.end() || it->second.generation!=generation)std::terminate();
    live.erase(it);
  }
  void Print() const override {}
  static int key() {
    static const int value=G4PhysicsModelCatalog::RegisterCustomModel("csim-rad/irt-cache-generation");
    return value;
  }
};
using Key=std::tuple<int,int,int>;
struct Entry {const G4Track* address; Identity identity;};
using Bins=std::map<Key,std::vector<Entry>>;
inline Bins& bins(){static thread_local Bins value;return value;}
inline void reset(){bins().clear();}
inline void inserted(int i,int j,int k,const G4Track* track) {
  const auto* tag=dynamic_cast<const Tag*>(track->GetAuxiliaryTrackInformation(Tag::key()));
  if(!tag) {
    if(track->GetAuxiliaryTrackInformation(Tag::key()))
      throw std::runtime_error("generation auxiliary slot occupied");
    auto* created=new Tag(*track);
    track->SetAuxiliaryTrackInformation(Tag::key(),created);
    tag=created;
  }
  if(registry().live.at(track).id!=track->GetTrackID())
    throw std::runtime_error("live track ID changed after bin insertion");
  bins()[{i,j,k}].push_back({track,{track->GetTrackID(),tag->generation}});
}
inline bool invalid(int i,int j,int k,int n,const G4Track* address) {
  const auto& expected=bins().at({i,j,k}).at(n);
  if(expected.address!=address)throw std::runtime_error("IRT cache identity order differs");
  const auto found=registry().live.find(address);
  // Never dereference a cached address here. It may no longer name a G4Track.
  return found==registry().live.end() || found->second.id!=expected.identity.id ||
         found->second.generation!=expected.identity.generation;
}
}
