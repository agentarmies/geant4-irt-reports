# Geant4 11.4.3 G4ManyFastLists end-sentinel reproducer

Apart from this README, these are the exact files from our recorded check,
unchanged; only the two output files were renamed. Source: Geant4 commit
2ee379e6843e55b9c6bbb835d2a2b03cc998fef0. No transport or chemistry runs.

- `order_old.cc` copies `SpaceBinning`, `IRTSampling` and the no-reaction
  tail of `Initialize` from G4DNAIRT.cc into a small class. It runs them on
  real `G4TrackManyList` objects in 12 layouts: no sublists, empty and
  occupied sublists, and sublists appended during `Sampling`. It writes one
  JSON file, named by its only argument.
- `order_fixed.cc` is the same test with the three loops replaced as in
  `irt-ordered-traversal-proposal.patch`.
- `IRTOrderedTracks.hh` is the patch's helper, `forEachIRTTrack`.
- `IRTCacheGuard.hh` is the cache guard from our separate report. Both tests
  include it; it does not touch the track lists.
- `CMakeLists.txt` is the CMake file we used. Only the targets `order_old`,
  `order_old_asan`, `order_fixed` and `order_fixed_asan` apply here. Its
  other targets name sources that are not in this package; delete them
  before configuring.
- `ubsan-order_old_asan.log` is the raw UBSan output of `order_old_asan`.
- `order_old-release-output.json` is the output of `order_old`, built
  without sanitizers. `order_fixed` and `order_fixed_asan` wrote
  byte-identical files.
- `ordered-regression-receipt.json` and `ordered-regression-tests.log` are
  our test record. Test 2 is the failure we declared in advance: the UBSan
  stop in `order_old_asan`. Tests 1, 3 and 4 pass.

Build and run as we recorded them (paths shortened), against an installed
Geant4 11.4.3:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$RAD_G4_PREFIX"
cmake --build build --parallel 1
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
ASAN_OPTIONS=abort_on_error=1:detect_leaks=1:symbolize=1 \
  ./build/order_old_asan order_old_asan.json
```

The `_asan` targets add `-g -fsanitize=address,undefined
-fno-omit-frame-pointer -fno-sanitize-recover=all`. We ran these commands
with the full CMake file in its original directory. We have not rebuilt
this set as a standalone package.

Source credit: Geant4 Collaboration. Test fixtures: Agent Armies Labs.
