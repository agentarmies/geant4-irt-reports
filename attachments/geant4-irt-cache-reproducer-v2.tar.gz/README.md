# Geant4 11.4.3 traditional IRT spatial-cache reproducer

This package builds the shipped chem6 example with an observer at the IRT
partner lookup. It leaves the installed Geant4 library unchanged. Source:
Geant4 commit 2ee379e6843e55b9c6bbb835d2a2b03cc998fef0.

Set RAD_G4_PREFIX to an existing Geant4 11.4.3 installation and load its
Geant4 dataset environment. Set OMP_NUM_THREADS=1, MKL_NUM_THREADS=1,
OPENBLAS_NUM_THREADS=1 and LP_NUM_THREADS=1. The macro uses one Geant4 thread.

```sh
cmake -S chem6 -B build-original -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH="$RAD_G4_PREFIX" -DWITH_GEANT4_UIVIS=OFF
cmake --build build-original --parallel 1
cmake -S chem6 -B build-guard -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH="$RAD_G4_PREFIX" -DWITH_GEANT4_UIVIS=OFF \
  -DCMAKE_CXX_FLAGS=-DRAD_BIN_IMPACT_SKIP=1
cmake --build build-guard --parallel 1
```

Run each executable in its own fresh output directory, passing an absolute
macro path. RAD_REPRO_ROOT denotes this extracted package directory.

```sh
"$RAD_REPRO_ROOT/build-original/chem6" "$RAD_REPRO_ROOT/beam-one-primary.mac"
"$RAD_REPRO_ROOT/build-original/chem6" "$RAD_REPRO_ROOT/beam-256.mac"
```

The same commands with build-guard run the diagnostic guard. Both macros
use seeds2026140001 and101; the first runs one primary, the second256.
The setup transports999.999keV electrons, accepts10–10.1keV primary energy
loss for the G-value scorer, uses physical option2, chemical option3,
traditional IRT, Meesungnoen2002 solvation and a1microsecond chemistry end.
There is no DNA geometry, DNA-removal action or damage scorer.

RAD_BIN_IMPACT lines count partner checks whose recorded insertion identity
is absent or replaced. Each track has an independent generation in auxiliary
track information; the registry removes it when that track is destroyed.
The observer never dereferences an absent/replaced partner to classify it.
The original variant then continues the original traversal. The guard skips
those entries. Counts are repeated checks, not distinct tracks or reactions.
Exact counts can vary with process layout; nonzero invalid-entry counts are
the structural witness. The one-primary case is the small reproducer; the
longer case is provided for the same setup used in the comparison.

The optional reaction/species callback requires ChemistryTracks.hh, included
here. bin_impact.py regenerates impact-G4DNAIRT.cc from original-G4DNAIRT.cc.
The original source SHA256 is
cdd2bec595262ac672f4d5d5f4b15b28d04f06d11579aca254692ca6e23b4686.
CMake uses relative package paths and Linux --export-dynamic intentionally.

Source credit: Geant4 Collaboration. Diagnostic additions: Agent Armies Labs.
