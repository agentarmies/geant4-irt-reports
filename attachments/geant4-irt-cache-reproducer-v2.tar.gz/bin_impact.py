"""Pinned-source diagnostic transform; never changes the installed library."""

def replace_once(text,old,new):
    if text.count(old)!=1:raise ValueError('impact source anchor changed: '+old)
    return text.replace(old,new,1)


def instrument_irt(text):
    for old,new in [
        ('#include "G4DNAIRT.hh"','#include "G4DNAIRT.hh"\n#include "BinImpact.hh"'),
        ('void G4DNAIRT::Initialize(){','void G4DNAIRT::Initialize(){\n  RadBinImpact::reset();'),
        ('spaceBinned[I][J][K].push_back(*it_begin);',
         'spaceBinned[I][J][K].push_back(*it_begin);\n    RadBinImpact::inserted(I,J,K,*it_begin);'),
        ('spaceBinned[I][J][K].push_back(productTrack);',
         'spaceBinned[I][J][K].push_back(productTrack);\n      RadBinImpact::inserted(I,J,K,productTrack);'),
        ('if(spaceBin[n]->GetTrackStatus() == fStopButAlive) continue;',
         'if(RadBinImpact::invalid(ii,jj,kk,n,spaceBin[n])) continue;\n'
         '          if(spaceBin[n]->GetTrackStatus() == fStopButAlive) continue;'),
    ]:text=replace_once(text,old,new)
    return text


def native_actions(text):
    text=replace_once(text,'#include "IRTWork.hh"','#include "IRTWork.hh"\n#include "BinImpact.hh"')
    text=replace_once(text,'    SiteInfo::key();','    RadBinImpact::Tag::key();\n    SiteInfo::key();')
    return replace_once(text,'    state.chemistryDiagnostics.flush();',
        '    RadBinImpact::report(state.event);\n    state.chemistryDiagnostics.flush();')
