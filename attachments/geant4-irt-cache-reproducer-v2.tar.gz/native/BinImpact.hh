#pragma once
// Diagnostic only. The installed Geant4 library and production runner are unchanged.
// Both diagnostic builds carry identical generation tags; only the guard differs.
#include "G4Track.hh"
#include "G4PhysicsModelCatalog.hh"
#include "G4VAuxiliaryTrackInformation.hh"
#include <cstdint>
#include <iostream>
#include <map>
#include <stdexcept>
#include <tuple>
#include <unordered_map>
#include <vector>

namespace RadBinImpact {
struct Identity {int id; std::uint64_t generation;};
struct Registry {
  std::uint64_t next=0;
  std::unordered_map<const G4Track*,Identity> live;
};
inline Registry& registry() {
  // Deliberately process-lived: Geant4 may destroy track metadata in teardown.
  // The map releases each entry when the track's owned auxiliary tag is deleted.
  static thread_local auto* value=new Registry;
  return *value;
}
struct Tag final : G4VAuxiliaryTrackInformation {
  const G4Track* track;
  std::uint64_t generation;
  explicit Tag(const G4Track& t):track(&t),generation(++registry().next) {
    if(!generation || registry().live.count(track))
      throw std::runtime_error("duplicate live molecular generation");
    registry().live.emplace(track,Identity{t.GetTrackID(),generation});
  }
  ~Tag() override {
    auto& live=registry().live;
    const auto it=live.find(track);
    if(it==live.end() || it->second.generation!=generation)std::terminate();
    live.erase(it);
  }
  void Print() const override {}
  static int key() {
    static const int value=G4PhysicsModelCatalog::RegisterCustomModel("csim-rad/bin-impact-generation");
    return value;
  }
};
using Key=std::tuple<int,int,int>;
struct Entry {const G4Track* address; Identity identity;};
struct Counts {
  std::uint64_t scanned=0,absent=0,reused=0,idMismatch=0,generationMismatch=0,skipped=0;
  std::map<Key,std::vector<Entry>> bins;
};
inline Counts& current(){static thread_local Counts value;return value;}
inline void reset(){current()=Counts{};}
inline void inserted(int i,int j,int k,const G4Track* track) {
  const auto* tag=dynamic_cast<const Tag*>(track->GetAuxiliaryTrackInformation(Tag::key()));
  if(!tag) {
    if(track->GetAuxiliaryTrackInformation(Tag::key()))
      throw std::runtime_error("generation auxiliary slot occupied");
    auto* created=new Tag(*track);
    track->SetAuxiliaryTrackInformation(Tag::key(),created);
    tag=created;
  }
  if(registry().live.at(track).id!=track->GetTrackID())
    throw std::runtime_error("live track ID changed after bin insertion");
  current().bins[{i,j,k}].push_back({track,{track->GetTrackID(),tag->generation}});
}
inline bool invalid(int i,int j,int k,int n,const G4Track* address) {
  auto& c=current();++c.scanned;
  const auto& expected=c.bins.at({i,j,k}).at(n);
  if(expected.address!=address)throw std::runtime_error("impact shadow bin order differs");
  const auto found=registry().live.find(address);
  bool bad=false;
  if(found==registry().live.end()){++c.absent;bad=true;}
  else {
    // The address is only a lookup key. Accept only BOTH immutable ID and generation.
    const bool id=found->second.id!=expected.identity.id;
    const bool generation=found->second.generation!=expected.identity.generation;
    if(id || generation){++c.reused;c.idMismatch+=id;c.generationMismatch+=generation;bad=true;}
  }
#ifdef RAD_BIN_IMPACT_SKIP
  if(bad)++c.skipped;
  return bad;
#else
  (void)bad;
  return false; // Observe only; preserve the original partner-loop behavior.
#endif
}
inline void report(int event) {
  const auto& c=current();
  std::cerr<<"RAD_BIN_IMPACT {\"event\":"<<event<<",\"scanned\":"<<c.scanned
    <<",\"absent\":"<<c.absent<<",\"reused\":"<<c.reused<<",\"id_mismatch\":"<<c.idMismatch
    <<",\"generation_mismatch\":"<<c.generationMismatch<<",\"skipped\":"<<c.skipped<<"}\n";
}
}
