#pragma once
#include "BinImpact.hh"
#include "ChemistryTracks.hh"
#include "G4EventManager.hh"
#include "G4Event.hh"
#include "G4ITTrackHolder.hh"
#include "G4Molecule.hh"
#include "G4MolecularConfiguration.hh"
#include "G4UserTimeStepAction.hh"
#include <algorithm>
#include <fstream>
#include <map>

class Chem6ImpactAction final : public G4UserTimeStepAction {
  std::map<std::string,std::size_t> reactions;
  std::ofstream out{"engineering-chemistry-summary.tsv"};
public:
  Chem6ImpactAction(){out<<"event\tkind\tspecies_or_reaction\tcount\n";}
  void StartProcessing() override {reactions.clear();}
  void UserReactionAction(const G4Track& a,const G4Track& b,const std::vector<G4Track*>* products) override {
    auto name=[](const G4Track& t) {
      auto* m=GetMolecule(t);
      if(!m)throw std::runtime_error("chem6 diagnostic reaction without molecule");
      return std::string(m->GetMolecularConfiguration()->GetName());
    };
    std::vector<std::string> reactants={name(a),name(b)},names;
    std::sort(reactants.begin(),reactants.end());
    if(products)for(auto* t:*products)names.push_back(name(*t));
    std::sort(names.begin(),names.end());
    std::string key=reactants[0]+" + "+reactants[1]+" ->";
    for(const auto& n:names)key+=" "+n;
    ++reactions[key];
  }
  void EndProcessing() override {
    const auto* event=G4EventManager::GetEventManager()->GetConstCurrentEvent();
    if(!event)throw std::runtime_error("chem6 diagnostic event missing");
    const int id=event->GetEventID();
    std::map<std::string,std::size_t> species;
    auto count=[&](G4Track& t) {
      auto* m=GetMolecule(t);
      if(!m)throw std::runtime_error("chem6 final molecule missing");
      ++species[m->GetMolecularConfiguration()->GetName()+" | status="+std::to_string(t.GetTrackStatus())];
    };
    auto* holder=G4ITTrackHolder::Instance();
    forEachChemistryTrack(*holder->GetMainList(),count);
    forEachChemistryTrack(*holder->GetSecondariesList(),count);
    for(const auto& row:reactions)out<<id<<"\treaction\t"<<row.first<<'\t'<<row.second<<'\n';
    for(const auto& row:species)out<<id<<"\tfinal_species_by_status\t"<<row.first<<'\t'<<row.second<<'\n';
    RadBinImpact::report(id);out.flush();
    if(!out.good())throw std::runtime_error("chem6 diagnostic write failed");
  }
};
