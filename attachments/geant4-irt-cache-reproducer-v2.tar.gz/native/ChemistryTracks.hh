#pragma once
#include "G4IT.hh"
#include "G4Material.hh"
#include "G4PhysicsModelCatalog.hh"
#include "G4Step.hh"
#include "G4TrackList.hh"
#include "G4VAuxiliaryTrackInformation.hh"
#include <stdexcept>

// G4Molecule owns the ordinary user-information slot. G4Track separately owns
// these auxiliary site labels. No chemistry state is replaced by a label.
struct SiteInfo final : G4VAuxiliaryTrackInformation {
  int site;
  explicit SiteInfo(int id):site(id) {}
  void Print() const override {}
  static int key() {
    static const int id=G4PhysicsModelCatalog::RegisterCustomModel("csim-rad/DNA-site");
    return id;
  }
  static const SiteInfo* get(const G4Track& track) {
    return dynamic_cast<const SiteInfo*>(track.GetAuxiliaryTrackInformation(key()));
  }
  static void attach(G4Track& track,int site) {
    if(!GetIT(track) || track.GetAuxiliaryTrackInformation(key()))
      throw std::runtime_error("invalid molecular track metadata ownership");
    track.SetAuxiliaryTrackInformation(key(),new SiteInfo(site));
  }
};

// 11.4.3 G4ManyFastLists::end()/HasReachedEnd call a member through a null
// sentinel. Traverse its same public ordered sublists without that helper.
// The action may change status, but must not add, remove or reorder entries.
template<class Action>
void forEachChemistryTrack(G4TrackManyList& list,Action action) {
  if(list.size()==0) return;
  auto* lists=list.begin().fLists;
  for(auto outer=lists->begin();outer!=lists->end();++outer) {
    auto* tracks=*outer;
    if(!tracks) throw std::runtime_error("null chemistry sublist");
    for(auto it=tracks->begin();it!=tracks->end();++it) action(**it);
  }
}

// The existing step-1 predicate and status action, factored for a fixture
// comparing the original and replacement traversal. No queue repair here.
struct NoA1Bookkeeping { void operator()(G4Track&) const {} };
template<class BeforeKill=NoA1Bookkeeping>
bool applyA1MaterialFilter(G4Track& track,BeforeKill beforeKill={}) {
  if(SiteInfo::get(track)) return false;
  if(!track.GetStep() || !track.GetStep()->GetPreStepPoint()->GetMaterial())
    throw std::runtime_error("A1 initial material unavailable");
  if(track.GetStep()->GetPreStepPoint()->GetMaterial()->GetName()!="G4_WATER") {
    beforeKill(track);
    track.SetTrackStatus(fStopAndKill);
    return true;
  }
  return false;
}
