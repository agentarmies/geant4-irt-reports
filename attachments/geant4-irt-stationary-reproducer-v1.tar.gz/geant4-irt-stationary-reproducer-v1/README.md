# Geant4 11.4.3 IRT near-stationary placement

This fixture links the unchanged installed G4DNAIRT. It creates a water world
and calls MakeReaction directly for two molecular parents, one product, and
1 ns elapsed time. It performs no particle transport and writes no damage file.
G4Random seed: 2026190001. The mobile coefficient is 4.9e-9 m²/s. The other
coefficient is exactly zero or 1e-150 m²/s, matching dnadamage2's DNA sentinel.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$RAD_G4_PREFIX"
cmake --build build --parallel 1
./build/placement A zero
./build/placement B zero
./build/placement A near
./build/placement B near
```

Arguments name the stationary parent's caller position (A or B) and coefficient
(zero or near). Each call prints one RAD_IMMOBILE_CONTRACT JSON observation.
The process returns 0 only if all raw parent/product coordinates are finite and
inside the world's ±1000 nm bounds. On the pinned release library the two zero
controls and B near return 0; A near returns 1, with an out-of-world product.
That nonzero exit is the reproduced contract failure, not a compilation error.
Keep each run's output separately. No output retry or suppression is needed.

The source is Geant4 commit 2ee379e6843e55b9c6bbb835d2a2b03cc998fef0.
G4DNAIRT.cc SHA256:
cdd2bec595262ac672f4d5d5f4b15b28d04f06d11579aca254692ca6e23b4686.
The source formula at lines 410–444 tests D against exact zero and otherwise
uses s12+s22*s22/s12 as a Gaussian width; a positive near-zero caller-A D
therefore enters that general branch. FindBin clamps invalid coordinates,
which is why this fixture checks the positions before any bin interpretation.

Credit: Geant4 Collaboration. Fixture derived from its public molecular API.
