// Diagnostic contract against the installed, unchanged Geant4 11.4.3 MakeReaction.
// No transport, damage records, or changes to the reaction implementation.
#include "G4DNAIRT.hh"
#include "G4Box.hh"
#include "G4GeometryManager.hh"
#include "G4ITReactionChange.hh"
#include "G4LogicalVolume.hh"
#include "G4MoleculeDefinition.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4Scheduler.hh"
#include "G4SystemOfUnits.hh"
#include "G4TransportationManager.hh"
#include "Randomize.hh"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <stdexcept>
#include <string>

bool finite(const G4ThreeVector& p) {
  return std::isfinite(p.x()) && std::isfinite(p.y()) && std::isfinite(p.z());
}
bool inside(const G4ThreeVector& p) {
  return finite(p) && std::max({std::abs(p.x()),std::abs(p.y()),std::abs(p.z())})<=1*um;
}
void position(const G4ThreeVector& p) {
  G4cout<<'['<<p.x()/nm<<','<<p.y()/nm<<','<<p.z()/nm<<']';
}
int main(int argc,char** argv) {
  if(argc!=3)throw std::runtime_error("order A|B and diffusion zero|near required");
  const std::string order=argv[1],kind=argv[2];
  if((order!="A" && order!="B") || (kind!="zero" && kind!="near"))
    throw std::runtime_error("invalid declared case");
  G4Random::setTheSeed(2026190001);
  // BuildTrack initializes the molecular navigator from the tracking world.
  // A real water world is required even though this fixture runs no transport.
  auto* solid=new G4Box("World",1*um,1*um,1*um);
  auto* logical=new G4LogicalVolume(solid,G4NistManager::Instance()->FindOrBuildMaterial("G4_WATER"),"World");
  auto* world=new G4PVPlacement(nullptr,{},logical,"World",nullptr,false,0);
  G4TransportationManager::GetTransportationManager()->GetNavigatorForTracking()->SetWorldVolume(world);
  G4GeometryManager::GetInstance()->CloseGeometry();
  const double stationaryD=kind=="zero" ? 0 : 1e-150*m2/s;
  const double mobileD=4.9e-9*m2/s;
  auto* table=G4MoleculeTable::Instance();
  auto* near=table->CreateConfiguration("Near",new G4MoleculeDefinition("Near",134*g/mole,stationaryD),0);
  auto* mobile=table->CreateConfiguration("Mobile",new G4MoleculeDefinition("Mobile",1*g/mole,mobileD),0);
  auto* product=table->CreateConfiguration("Product",new G4MoleculeDefinition("Product",135*g/mole,stationaryD),0);
  auto* reaction=new G4DNAMolecularReactionData(1e9*1e-3*m3/(mole*s),near,mobile);
  reaction->SetEffectiveReactionRadius(.7*nm);
  reaction->AddProduct(product);
  auto* reactions=G4DNAMolecularReactionTable::Instance();reactions->SetReaction(reaction);
  auto* scheduler=G4Scheduler::Instance();scheduler->SetEndTime(20*us);
  const double now=scheduler->GetGlobalTime();
  auto* a=(new G4Molecule(order=="A" ? near : mobile))->BuildTrack(now,G4ThreeVector(1,2,3)*nm);
  auto* b=(new G4Molecule(order=="A" ? mobile : near))->BuildTrack(now,G4ThreeVector(3,4,5)*nm);
  a->SetTrackID(11);b->SetTrackID(22);
  auto* holder=G4ITTrackHolder::Instance();holder->Push(a);holder->Push(b);
  double mergedTime=0;
  if(!holder->MergeNextTimeToMainList(mergedTime))throw std::runtime_error("fixture parents not in main list");
  G4DNAIRT irt;irt.SetReactionTable(reactions);irt.SpaceBinning();
  // Only elapsed time matters to this direct call. Preserve the scheduler's
  // existing clock and put both parent timestamps exactly one ns before it.
  a->SetGlobalTime(now-1*ns);b->SetGlobalTime(now-1*ns);
  const double d1=GetMolecule(a)->GetDiffusionCoefficient(),d2=GetMolecule(b)->GetDiffusionCoefficient();
  const double s12=2*d1*ns,s22=2*d2*ns;
  const double width=s12==0 || s22==0 ? 0 : s12+s22*s22/s12;
  auto changes=irt.MakeReaction(*a,*b);
  if(!changes || changes->GetNumberOfSecondaries()!=1)throw std::runtime_error("real MakeReaction did not produce its one inert product");
  const auto& p=changes->GetSecondary(0)->GetPosition();
  const bool allFinite=finite(a->GetPosition()) && finite(b->GetPosition()) && finite(p);
  const bool allInside=inside(a->GetPosition()) && inside(b->GetPosition()) && inside(p);
  G4cout<<std::setprecision(17)<<"RAD_IMMOBILE_CONTRACT {\"order\":\""<<order<<"\",\"diffusion\":\""<<kind
    <<"\",\"d1_m2_per_s\":"<<d1/(m2/s)<<",\"d2_m2_per_s\":"<<d2/(m2/s)
    <<",\"elapsed_ns\":1,\"numeric_gaussian_width_internal\":"<<width
    <<",\"caller_a_position_nm\":";position(a->GetPosition());
  G4cout<<",\"caller_b_position_nm\":";position(b->GetPosition());
  G4cout<<",\"product_position_nm\":";position(p);
  G4cout<<",\"all_positions_finite\":"<<(allFinite ? "true" : "false")
    <<",\"all_positions_inside_world\":"<<(allInside ? "true" : "false")
    <<",\"returned_parent_ids\":["<<changes->GetTrackA()->GetTrackID()<<','<<changes->GetTrackB()->GetTrackID()
    <<"],\"world_half_length_nm\":1000}"<<G4endl;
  // Complete the holder's normal track-removal path before clearing lists;
  // this fixture deliberately bypasses the scheduler that normally does it.
  holder->PushToKill(a);holder->PushToKill(b);
  holder->PushToKill(changes->GetSecondary(0));
  changes.reset();holder->KillTracks();holder->Clear();
  return allFinite && allInside ? 0 : 1;
}
