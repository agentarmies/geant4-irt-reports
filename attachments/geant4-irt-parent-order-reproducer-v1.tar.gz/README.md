# Geant4 11.4.3 IRT parent-order reproducer

This fixture calls the unchanged installed G4ITReactionChange class on two
stack-owned tracks. It tests both caller/address orders. It then exhibits
the assignment/readback sequence from G4DNAIRT.cc448–471 using illustrative
positions and diffusion weights. It performs no transport, chemistry, random
sampling or damage scoring. It is not a full MakeReaction call.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH="$RAD_G4_PREFIX"
cmake --build build --parallel 1
./build/parent_order
```

The output shows caller IDs11 and22 returned as11/22 when A is at the lower
address, but22/11 when A is at the higher address. Position assignments to
the callers therefore swap. The illustrative diffusion-weighted product site
is7nm in the first case and3nm in the second. These are algebraic fixture
values, not simulated molecular displacements.

mapping-fix.patch proposes assigning r1/r2 to &trackA/&trackB directly. The
fixture does not apply that patch to the installed library. The attached
report distinguishes the source mechanism, dynamic trace and validation.

Source: Geant4 11.4.3, commit2ee379e6843e55b9c6bbb835d2a2b03cc998fef0.
Original G4DNAIRT.cc SHA256:
cdd2bec595262ac672f4d5d5f4b15b28d04f06d11579aca254692ca6e23b4686.
Source credit: Geant4 Collaboration. Diagnostic fixture: Agent Armies Labs.
