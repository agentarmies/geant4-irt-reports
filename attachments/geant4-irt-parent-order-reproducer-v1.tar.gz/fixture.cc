// Proposed diagnostic only; not executed and not a full MakeReaction test.
// Calls unchanged Geant4 11.4.3 G4ITReactionChange, then exhibits the
// assignment/readback sequence from original G4DNAIRT.cc:448-471.
#include "G4ITReactionChange.hh"
#include "G4SystemOfUnits.hh"
#include "G4Track.hh"
#include <array>
#include <functional>
#include <iomanip>
#include <iostream>

int main() {
  std::array<G4Track, 2> storage;
  G4Track* low = &storage[0];
  G4Track* high = &storage[1];
  if (std::less<const G4Track*>{}(high, low)) std::swap(low, high);
  std::cout << std::setprecision(17) << "{\"actual_make_reaction_run\":false,\"cases\":[";
  for (int reversed = 0; reversed != 2; ++reversed) {
    auto* callerA = reversed ? high : low;
    auto* callerB = reversed ? low : high;
    callerA->SetTrackID(11);
    callerB->SetTrackID(22);
    callerA->SetPosition({0, 0, 0});
    callerB->SetPosition({0, 0, 0});
    G4ITReactionChange changes;
    changes.Initialize(*callerA, *callerB);
    const G4ThreeVector r1(1 * nm, 0, 0), r2(9 * nm, 0, 0);
    auto* returnedA = const_cast<G4Track*>(changes.GetTrackA());
    auto* returnedB = const_cast<G4Track*>(changes.GetTrackB());
    returnedA->SetPosition(r1);
    returnedB->SetPosition(r2);
    // Algebraic example of the source formula, not a sampled chemistry step.
    const double sqrtD1 = 3, sqrtD2 = 1;
    const auto site = (sqrtD2 * callerA->GetPosition() + sqrtD1 * callerB->GetPosition()) /
                      (sqrtD1 + sqrtD2);
    if (reversed) std::cout << ',';
    std::cout << "{\"caller_a_has_lower_address\":" << (reversed ? "false" : "true")
              << ",\"returned_a_id\":" << returnedA->GetTrackID()
              << ",\"returned_b_id\":" << returnedB->GetTrackID()
              << ",\"caller_a_x_nm\":" << callerA->GetPosition().x() / nm
              << ",\"caller_b_x_nm\":" << callerB->GetPosition().x() / nm
              << ",\"illustrative_site_x_nm\":" << site.x() / nm << '}';
  }
  std::cout << "]}\n";
}
